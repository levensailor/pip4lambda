from __future__ import unicode_literals
from netmiko.alcatel.alcatel_sros_ssh import AlcatelSrosSSH
from netmiko.alcatel.alcatel_aos_ssh import AlcatelAosSSH

__all__ = ["AlcatelSrosSSH", "AlcatelAosSSH"]
