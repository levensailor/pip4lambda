from __future__ import unicode_literals
from netmiko.rad.rad_etx import RadETXSSH
from netmiko.rad.rad_etx import RadETXTelnet

__all__ = ["RadETXSSH", "RadETXTelnet"]
